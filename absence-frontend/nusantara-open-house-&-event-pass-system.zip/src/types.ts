export type AttendeeRole = 'Siswa' | 'Guru Pendamping';

export type PassStatus = 'UNREDEEMED' | 'REDEEMED';

export type TrialClassType = 'IT' | 'DKV' | 'KULINER' | 'MOBILE_LEGENDS';

export type InfoSourceType = 'Medsos' | 'Banner' | 'Event' | 'Teman' | 'Website';

export interface TrialClassMeta {
  id: TrialClassType;
  label: string;
  subtitle: string;
}

export const TRIAL_CLASS_OPTIONS: TrialClassMeta[] = [
  { id: 'IT', label: 'IT', subtitle: 'Web, App & IoT' },
  { id: 'DKV', label: 'DKV', subtitle: 'Desain & Animasi' },
  { id: 'KULINER', label: 'KULINER', subtitle: 'Tata Boga & Pastry' },
  { id: 'MOBILE_LEGENDS', label: 'MOBILE LEGENDS', subtitle: 'Esports Strategy' },
];

export const INFO_SOURCE_OPTIONS: InfoSourceType[] = [
  'Medsos',
  'Banner',
  'Event',
  'Teman',
  'Website',
];

export interface AttendeePass {
  id: string;
  couponCode: string; // e.g., ABSC-0001
  fullName: string;
  nisnOrNip: string;
  schoolOrigin: string;
  role: AttendeeRole;
  trialClass: TrialClassType;
  infoSource: InfoSourceType;
  infoSourceDetail?: string;
  registrationSource: 'Reg-Online' | 'Walk-In';
  status: PassStatus;
  registeredAt: string;
  checkedInAt?: string;
}

export interface ScanLogEntry {
  id: string;
  timestamp: string;
  relativeTime: string;
  couponCode: string;
  fullName: string;
  schoolOrigin: string;
  role: AttendeeRole;
  trialClass: TrialClassType;
  infoSource: InfoSourceType;
  infoSourceDetail?: string;
  scanMethod: 'auto' | 'manual';
  status: 'success' | 'rejected' | 'manual';
  statusText: string;
  subStatusText?: string;
  deskName: string;
  verifierNote: string;
}

export interface ScanFeedback {
  id: string;
  type: 'success' | 'duplicate' | 'invalid';
  title: string;
  message: string;
  codeScanned: string;
  pass?: AttendeePass;
  timestamp: string;
}

export const EDUPASS_LOGO_URL =
  'https://lh3.googleusercontent.com/aida/AEtjO1X0_htjdU4wC-Nq_TAEtDflxR9GTY7Wt6e-cak6MIICgRqkpJ735U25yz816hzoB-We2j1DBvJfVZAP0hERQwhYHkrdzf6BQjqKrbo-fybuCXdtWCzABVyhSSL_J10E1oo27H6h3INO57mB0qyN8uW4GHPDurZiI8GpdxxnqYjL5WSS_d1ZI4biBJJh6Eu7hbsriDKLtwvoyahRXUuf9sqOl5LzDl8V58ZPESLFJDM';

export const INITIAL_ATTENDEES: AttendeePass[] = [
  {
    id: '1',
    couponCode: 'ABSC-0001',
    fullName: 'Ahmad Rizky',
    nisnOrNip: '0067891234',
    schoolOrigin: 'SMK Negeri 1 Jakarta',
    role: 'Siswa',
    trialClass: 'DKV',
    infoSource: 'Medsos',
    infoSourceDetail: 'Instagram @edupass.id',
    registrationSource: 'Reg-Online',
    status: 'REDEEMED',
    registeredAt: '07:45 WIB',
    checkedInAt: '09:15 WIB',
  },
  {
    id: '2',
    couponCode: 'ABSC-0002',
    fullName: 'Dra. Nurhayati',
    nisnOrNip: '197805122005012004',
    schoolOrigin: 'SMA Negeri 70 Jakarta',
    role: 'Guru Pendamping',
    trialClass: 'IT',
    infoSource: 'Event',
    infoSourceDetail: 'EduFair Jakarta Selatan',
    registrationSource: 'Reg-Online',
    status: 'UNREDEEMED',
    registeredAt: '07:50 WIB',
  },
  {
    id: '3',
    couponCode: 'ABSC-0003',
    fullName: 'Kevin Sanjaya Pratama',
    nisnOrNip: '0071298455',
    schoolOrigin: 'SMP Negeri 115 Jakarta',
    role: 'Siswa',
    trialClass: 'MOBILE_LEGENDS',
    infoSource: 'Teman',
    registrationSource: 'Walk-In',
    status: 'REDEEMED',
    registeredAt: '08:02 WIB',
    checkedInAt: '08:42 WIB',
  },
  {
    id: '4',
    couponCode: 'ABSC-0004',
    fullName: 'Siti Sarah Zahira',
    nisnOrNip: '0069384721',
    schoolOrigin: 'SMA Islam Al-Azhar 1',
    role: 'Siswa',
    trialClass: 'KULINER',
    infoSource: 'Banner',
    infoSourceDetail: 'Banner Depan Gerbang Sekolah',
    registrationSource: 'Reg-Online',
    status: 'UNREDEEMED',
    registeredAt: '08:06 WIB',
  },
  {
    id: '5',
    couponCode: 'ABSC-0005',
    fullName: 'Muhammad Fikri Haikal',
    nisnOrNip: '0075549021',
    schoolOrigin: 'SMK Telkom Sandhy Putra',
    role: 'Siswa',
    trialClass: 'IT',
    infoSource: 'Website',
    registrationSource: 'Reg-Online',
    status: 'REDEEMED',
    registeredAt: '08:08 WIB',
    checkedInAt: '08:10 WIB',
  },
  {
    id: '6',
    couponCode: 'ABSC-0006',
    fullName: 'Drs. Bambang Sutrisno',
    nisnOrNip: '196903151998021001',
    schoolOrigin: 'SMK Negeri 48 Jakarta',
    role: 'Guru Pendamping',
    trialClass: 'DKV',
    infoSource: 'Event',
    infoSourceDetail: 'Sosialisasi BK Provinsi',
    registrationSource: 'Reg-Online',
    status: 'UNREDEEMED',
    registeredAt: '08:15 WIB',
  },
  {
    id: '7',
    couponCode: 'ABSC-0042',
    fullName: 'Ahmad Rizky Pratama',
    nisnOrNip: '0068819201',
    schoolOrigin: 'SMK Negeri 1 Jakarta',
    role: 'Siswa',
    trialClass: 'DKV',
    infoSource: 'Medsos',
    infoSourceDetail: 'TikTok Live Open House',
    registrationSource: 'Reg-Online',
    status: 'REDEEMED',
    registeredAt: '08:20 WIB',
    checkedInAt: '09:18 WIB',
  },
  {
    id: '8',
    couponCode: 'ABSC-0089',
    fullName: 'Bambang Hariyanto, S.Pd.',
    nisnOrNip: '198002112006041009',
    schoolOrigin: 'SMA Negeri 70 Jakarta',
    role: 'Guru Pendamping',
    trialClass: 'IT',
    infoSource: 'Website',
    registrationSource: 'Walk-In',
    status: 'UNREDEEMED',
    registeredAt: '08:30 WIB',
  },
];

export const INITIAL_SCAN_LOGS: ScanLogEntry[] = [
  {
    id: 'log-1',
    timestamp: '09:18:42 WIB',
    relativeTime: 'Baru saja (12 dtk lalu)',
    couponCode: 'ABSC-0042',
    fullName: 'Ahmad Rizky Pratama',
    schoolOrigin: 'SMK Negeri 1 Jakarta',
    role: 'Siswa',
    trialClass: 'DKV',
    infoSource: 'Medsos',
    infoSourceDetail: 'TikTok Live Open House',
    scanMethod: 'auto',
    status: 'success',
    statusText: '200 Valid',
    deskName: 'Admin Loket 01',
    verifierNote: 'ID: ADM-JKT-09',
  },
  {
    id: 'log-2',
    timestamp: '09:17:15 WIB',
    relativeTime: '1 mnt lalu',
    couponCode: 'ABSC-0018',
    fullName: 'Clarissa Angelica Putri',
    schoolOrigin: 'SMA Kristen 3 PENABUR',
    role: 'Siswa',
    trialClass: 'IT',
    infoSource: 'Medsos',
    infoSourceDetail: 'Instagram Story',
    scanMethod: 'auto',
    status: 'rejected',
    statusText: '422 Duplikat',
    subStatusText: 'Sudah dipakai 08:34 WIB',
    deskName: 'Admin Loket 01',
    verifierNote: 'Auto-Interception',
  },
  {
    id: 'log-3',
    timestamp: '09:16:04 WIB',
    relativeTime: '2 mnt lalu',
    couponCode: 'ABSC-0089',
    fullName: 'Bambang Hariyanto, S.Pd.',
    schoolOrigin: 'SMA Negeri 70 Jakarta',
    role: 'Guru Pendamping',
    trialClass: 'IT',
    infoSource: 'Website',
    scanMethod: 'manual',
    status: 'manual',
    statusText: '200 Valid',
    deskName: 'Admin Loket 01',
    verifierNote: 'Override: Kamera Buram',
  },
  {
    id: 'log-4',
    timestamp: '09:14:50 WIB',
    relativeTime: '4 mnt lalu',
    couponCode: 'ABSC-0112',
    fullName: 'Nabila Zahra Rahmadani',
    schoolOrigin: 'SMK Pariwisata Metland',
    role: 'Siswa',
    trialClass: 'KULINER',
    infoSource: 'Banner',
    infoSourceDetail: 'Spanduk Lobby Sekolah',
    scanMethod: 'auto',
    status: 'success',
    statusText: '200 Valid',
    deskName: 'Admin Loket 02',
    verifierNote: 'ID: ADM-BDG-02',
  },
  {
    id: 'log-5',
    timestamp: '09:12:33 WIB',
    relativeTime: '6 mnt lalu',
    couponCode: 'ABSC-0042',
    fullName: 'Ahmad Rizky Pratama',
    schoolOrigin: 'Percobaan Ulang / Tangkapan Layar Palsu',
    role: 'Siswa',
    trialClass: 'DKV',
    infoSource: 'Medsos',
    scanMethod: 'auto',
    status: 'rejected',
    statusText: '422 Duplikat',
    subStatusText: 'Terverifikasi 6 mnt lalu',
    deskName: 'Admin Loket 01',
    verifierNote: 'Auto-Blocked',
  },
  {
    id: 'log-6',
    timestamp: '09:10:19 WIB',
    relativeTime: '8 mnt lalu',
    couponCode: 'ABSC-0205',
    fullName: 'Kevin Sanjaya Wijaya',
    schoolOrigin: 'SMA Kolese Gonzaga',
    role: 'Siswa',
    trialClass: 'MOBILE_LEGENDS',
    infoSource: 'Teman',
    scanMethod: 'auto',
    status: 'success',
    statusText: '200 Valid',
    deskName: 'Admin Loket 01',
    verifierNote: 'ID: ADM-JKT-09',
  },
  {
    id: 'log-7',
    timestamp: '09:07:41 WIB',
    relativeTime: '11 mnt lalu',
    couponCode: 'ABSC-0177',
    fullName: 'Farhan Al-Ghifari',
    schoolOrigin: 'MAN 4 Jakarta Selatan',
    role: 'Siswa',
    trialClass: 'IT',
    infoSource: 'Event',
    infoSourceDetail: 'Roadshow Kampus',
    scanMethod: 'auto',
    status: 'success',
    statusText: '200 Valid',
    deskName: 'Admin Loket 02',
    verifierNote: 'ID: ADM-BDG-02',
  },
];
