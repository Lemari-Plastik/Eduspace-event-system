/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { CheckCircle2, ArrowLeft, Ticket, Lock, User, Eye, EyeOff, X, AlertCircle } from 'lucide-react';
import {
  AttendeePass,
  AttendeeRole,
  EDUPASS_LOGO_URL,
  InfoSourceType,
  INITIAL_ATTENDEES,
  INITIAL_SCAN_LOGS,
  ScanFeedback,
  ScanLogEntry,
  TrialClassType
} from './types';
import { RegistrationView } from './components/RegistrationView';
import { DigitalPassCard } from './components/DigitalPassCard';
import { AdminPageId, AdminScannerDesk } from './components/AdminScannerDesk';
import { ScannerModal } from './components/ScannerModal';

type UserRoleMode = 'user' | 'admin';

const STORAGE_KEY_ATTENDEES = 'edupass_openhouse_attendees_v3';
const STORAGE_KEY_LOGS = 'edupass_openhouse_logs_v4';
const STORAGE_KEY_MY_PASS = 'edupass_openhouse_my_pass_id_v3';

export default function App() {
  const [roleMode, setRoleMode] = useState<UserRoleMode>('user');
  const [adminPage, setAdminPage] = useState<AdminPageId>('admin-participants');

  // Admin Login Modal state
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const [attendees, setAttendees] = useState<AttendeePass[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ATTENDEES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback
    }
    return INITIAL_ATTENDEES;
  });

  const [scanLogs, setScanLogs] = useState<ScanLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_LOGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback
    }
    return INITIAL_SCAN_LOGS;
  });

  const [myCreatedPassId, setMyCreatedPassId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_MY_PASS);
    } catch {
      return null;
    }
  });

  const [userStep, setUserStep] = useState<'form' | 'my-ticket'>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_MY_PASS) ? 'my-ticket' : 'form';
    } catch {
      return 'form';
    }
  });

  const [scanFeedback, setScanFeedback] = useState<ScanFeedback | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ATTENDEES, JSON.stringify(attendees));
    } catch {
      // Ignore
    }
  }, [attendees]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(scanLogs));
    } catch {
      // Ignore
    }
  }, [scanLogs]);

  useEffect(() => {
    try {
      if (myCreatedPassId) {
        localStorage.setItem(STORAGE_KEY_MY_PASS, myCreatedPassId);
      } else {
        localStorage.removeItem(STORAGE_KEY_MY_PASS);
      }
    } catch {
      // Ignore
    }
  }, [myCreatedPassId]);

  const openLoginModal = () => {
    setAdminUsername('');
    setAdminPassword('');
    setShowPassword(false);
    setLoginError(null);
    setIsLoginModalOpen(true);
  };

  const closeLoginModal = () => {
    setIsLoginModalOpen(false);
    setLoginError(null);
  };

  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminUsername.trim() === 'admin' && adminPassword === 'admin123') {
      setIsLoginModalOpen(false);
      setLoginError(null);
      setAdminUsername('');
      setAdminPassword('');
      setRoleMode('admin');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setLoginError('Username atau password salah. Gunakan kredensial admin yang valid.');
    }
  };

  const getNextCouponCode = (): string => {
    let maxNum = 0;
    for (const item of attendees) {
      const match = item.couponCode.match(/ABSC-(\d+)/i);
      if (match) {
        const num = parseInt(match[1], 10);
        if (num > maxNum) maxNum = num;
      }
    }
    const nextNum = maxNum + 1;
    return `ABSC-${String(nextNum).padStart(4, '0')}`;
  };

  const getCurrentTimeWib = (): string => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes} WIB`;
  };

  const getCurrentTimeWithSecondsWib = (): string => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds} WIB`;
  };

  const handleRegister = (newPassData: {
    fullName: string;
    nisnOrNip: string;
    schoolOrigin: string;
    role: AttendeeRole;
    trialClass: TrialClassType;
    infoSource: InfoSourceType;
    infoSourceDetail?: string;
  }): AttendeePass => {
    const newPass: AttendeePass = {
      id: `${Date.now()}`,
      couponCode: getNextCouponCode(),
      fullName: newPassData.fullName,
      nisnOrNip: newPassData.nisnOrNip,
      schoolOrigin: newPassData.schoolOrigin,
      role: newPassData.role,
      trialClass: newPassData.trialClass,
      infoSource: newPassData.infoSource,
      infoSourceDetail: newPassData.infoSourceDetail,
      registrationSource: 'Reg-Online',
      status: 'UNREDEEMED',
      registeredAt: getCurrentTimeWib(),
    };

    setAttendees((prev) => [newPass, ...prev]);
    setMyCreatedPassId(newPass.id);
    setUserStep('my-ticket');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return newPass;
  };

  const handleProcessScanCode = (
    rawCode: string,
    method: 'auto' | 'manual'
  ): ScanFeedback => {
    const code = rawCode.trim().toUpperCase();
    const timestamp = getCurrentTimeWib();
    const fullTimestamp = getCurrentTimeWithSecondsWib();
    const target = attendees.find((a) => a.couponCode.toUpperCase() === code);

    if (!target) {
      const rejectedEntry: ScanLogEntry = {
        id: `log-${Date.now()}`,
        timestamp: fullTimestamp,
        relativeTime: 'Baru saja',
        couponCode: code,
        fullName: 'Kupon Tidak Dikenali',
        schoolOrigin: 'Kode Tidak Valid',
        role: 'Siswa',
        trialClass: 'IT',
        infoSource: 'Website',
        scanMethod: method,
        status: 'rejected',
        statusText: '422 Tidak Valid',
        subStatusText: 'Kode tidak terdaftar',
        deskName: 'Admin Loket 01',
        verifierNote: 'Auto-Blocked',
      };
      setScanLogs((prev) => [rejectedEntry, ...prev]);

      const fb: ScanFeedback = {
        id: `scan-${Date.now()}`,
        type: 'invalid',
        title: 'Kode Kupon Tidak Terdaftar',
        message: `Kode "${code}" tidak ditemukan dalam basis data peserta Open House 2026.`,
        codeScanned: code,
        timestamp,
      };
      setScanFeedback(fb);
      return fb;
    }

    if (target.status === 'REDEEMED') {
      const duplicateEntry: ScanLogEntry = {
        id: `log-${Date.now()}`,
        timestamp: fullTimestamp,
        relativeTime: 'Baru saja',
        couponCode: target.couponCode,
        fullName: target.fullName,
        schoolOrigin: target.schoolOrigin,
        role: target.role,
        trialClass: target.trialClass,
        infoSource: target.infoSource,
        infoSourceDetail: target.infoSourceDetail,
        scanMethod: method,
        status: 'rejected',
        statusText: '422 Duplikat',
        subStatusText: `Sudah dipakai ${target.checkedInAt || '08:30 WIB'}`,
        deskName: 'Admin Loket 01',
        verifierNote: 'Auto-Interception',
      };
      setScanLogs((prev) => [duplicateEntry, ...prev]);

      const fb: ScanFeedback = {
        id: `scan-${Date.now()}`,
        type: 'duplicate',
        title: 'Peringatan: Kupon Sudah Di-scan',
        message: `Kupon ${target.couponCode} milik ${target.fullName} sudah pernah diverifikasi pada ${
          target.checkedInAt || 'sebelumnya'
        }.`,
        codeScanned: code,
        pass: target,
        timestamp,
      };
      setScanFeedback(fb);
      return fb;
    }

    const updatedPass: AttendeePass = {
      ...target,
      status: 'REDEEMED',
      checkedInAt: timestamp,
    };

    setAttendees((prev) =>
      prev.map((item) => (item.id === target.id ? updatedPass : item))
    );

    const successEntry: ScanLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: fullTimestamp,
      relativeTime: 'Baru saja',
      couponCode: target.couponCode,
      fullName: target.fullName,
      schoolOrigin: target.schoolOrigin,
      role: target.role,
      trialClass: target.trialClass,
      infoSource: target.infoSource,
      infoSourceDetail: target.infoSourceDetail,
      scanMethod: method,
      status: method === 'manual' ? 'manual' : 'success',
      statusText: '200 Valid',
      deskName: 'Admin Loket 01',
      verifierNote: method === 'manual' ? 'Override: Input Loket' : 'ID: ADM-JKT-09',
    };
    setScanLogs((prev) => [successEntry, ...prev]);

    const fb: ScanFeedback = {
      id: `scan-${Date.now()}`,
      type: 'success',
      title: 'Kehadiran & Kupon Terverifikasi',
      message: `Selamat datang, ${target.fullName}! Kehadiran tercatat pada ${timestamp}.`,
      codeScanned: code,
      pass: updatedPass,
      timestamp,
    };
    setScanFeedback(fb);
    return fb;
  };

  const handleQuickRedeem = (passId: string) => {
    const target = attendees.find((a) => a.id === passId);
    if (!target) return;
    handleProcessScanCode(target.couponCode, 'manual');
  };

  const handleDeleteAttendee = (passId: string) => {
    setAttendees((prev) => prev.filter((a) => a.id !== passId));
    if (myCreatedPassId === passId) {
      setMyCreatedPassId(null);
      setUserStep('form');
    }
  };

  const myCreatedPass = attendees.find((a) => a.id === myCreatedPassId) || null;

  // =========================================================================
  // RENDER ADMIN ROLE (3 Pages: Barcode Scanner, Riwayat Aktivitas, Peserta)
  // =========================================================================
  if (roleMode === 'admin') {
    return (
      <>
        <AdminScannerDesk
          attendees={attendees}
          scanLogs={scanLogs}
          activePage={adminPage}
          onChangePage={(page) => setAdminPage(page)}
          onProcessScanCode={handleProcessScanCode}
          onQuickRedeem={handleQuickRedeem}
          onDeleteAttendee={handleDeleteAttendee}
          onLogout={() => setRoleMode('user')}
        />
        <ScannerModal
          feedback={scanFeedback}
          onClose={() => setScanFeedback(null)}
        />
      </>
    );
  }

  // =========================================================================
  // RENDER REGULAR USER ROLE (Welcome Hero -> Form -> QR Ticket)
  // =========================================================================
  return (
    <div className="min-h-screen flex flex-col bg-[#FFF3E3]">
      {/* Minimal Header for Regular User */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-[#E2E8F0] no-print">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-4 px-4 sm:px-6 h-16">
          <div className="flex items-center gap-2.5">
            <img
              alt="EduPass Logo"
              referrerPolicy="no-referrer"
              className="h-7 w-auto object-contain"
              src={EDUPASS_LOGO_URL}
            />
            <span className="font-display text-[18px] font-bold tracking-tight text-[#181b2b] whitespace-nowrap">
              EduPass Open House
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            {myCreatedPass && (
              <button
                type="button"
                onClick={() =>
                  setUserStep(userStep === 'form' ? 'my-ticket' : 'form')
                }
                className="px-3.5 py-2 rounded-xl bg-[#f4f2ff] hover:bg-[#e5e6fe] text-[#32328a] text-[13px] font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Ticket className="w-4 h-4" />
                <span>
                  {userStep === 'form'
                    ? `Lihat Tiket Saya (${myCreatedPass.couponCode})`
                    : 'Buat Pendaftaran Baru'}
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={openLoginModal}
              className="px-3.5 py-2 rounded-xl bg-[#181b2b] hover:bg-[#2c2f41] text-white text-[13px] font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
            >
              <span className="material-symbols-outlined text-[16px] text-[#9fa0ff]">
                admin_panel_settings
              </span>
              <span>Login Admin</span>
            </button>
          </div>
        </div>
      </header>

      {/* Admin Login Popup Modal */}
      {isLoginModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#181b2b]/50 backdrop-blur-sm p-4"
          onClick={closeLoginModal}
        >
          <div
            className="bg-white rounded-[24px] max-w-md w-full p-6 sm:p-7 shadow-[0_24px_60px_rgba(24,27,43,0.2)] border border-[#E2E8F0] relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={closeLoginModal}
              aria-label="Tutup modal login"
              className="absolute top-5 right-5 w-9 h-9 rounded-full bg-[#F8FAFC] hover:bg-[#E2E8F0]/70 text-[#464651] flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-11 h-11 rounded-2xl bg-[#181b2b] flex items-center justify-center text-[#9FA0FF] shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-display text-[19px] font-bold text-[#181b2b] leading-tight">
                  Autentikasi Admin Loket
                </h3>
                <p className="text-[13px] text-[#464651] mt-0.5">
                  Masukkan kredensial khusus petugas untuk membuka konsol.
                </p>
              </div>
            </div>

            {loginError && (
              <div className="mb-4 rounded-xl bg-[#ffdad6]/70 border border-[#ba1a1a]/20 px-3.5 py-2.5 flex items-start gap-2.5 text-[#ba1a1a] text-[13px]">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="font-medium leading-snug">{loginError}</span>
              </div>
            )}

            <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[13px] font-semibold text-[#181b2b] mb-1.5">
                  Username Admin
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#777682] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    autoFocus
                    value={adminUsername}
                    onChange={(e) => {
                      setAdminUsername(e.target.value);
                      if (loginError) setLoginError(null);
                    }}
                    placeholder="Masukkan username admin"
                    className="w-full h-12 pl-10 pr-4 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-[14px] text-[#181b2b] focus:outline-none focus:bg-white focus:border-[#4b4ca3] focus:ring-2 focus:ring-[#9FA0FF]/30 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[13px] font-semibold text-[#181b2b] mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-[#777682] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={adminPassword}
                    onChange={(e) => {
                      setAdminPassword(e.target.value);
                      if (loginError) setLoginError(null);
                    }}
                    placeholder="Masukkan password"
                    className="w-full h-12 pl-10 pr-11 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] text-[14px] text-[#181b2b] focus:outline-none focus:bg-white focus:border-[#4b4ca3] focus:ring-2 focus:ring-[#9FA0FF]/30 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((prev) => !prev)}
                    aria-label={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg text-[#777682] hover:text-[#181b2b] flex items-center justify-center cursor-pointer"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={closeLoginModal}
                  className="h-11 px-4 rounded-xl bg-[#F8FAFC] hover:bg-[#E2E8F0]/70 text-[#464651] text-[13px] font-semibold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="h-11 px-5 rounded-xl bg-[#181b2b] hover:bg-[#2c2f41] text-white text-[13px] font-semibold inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[17px] text-[#9FA0FF]">
                    login
                  </span>
                  <span>Masuk sebagai Admin</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main Content for Regular User */}
      <main className="flex-1">
        {userStep === 'my-ticket' && myCreatedPass ? (
          <div className="max-w-lg mx-auto px-4 py-8 sm:py-10 space-y-5">
            {/* Success Confirmation Banner */}
            <div className="rounded-[20px] bg-[#D5E8E6] border border-[#506260]/25 px-5 py-4 flex items-start gap-3.5 shadow-resting-card no-print">
              <div className="w-9 h-9 rounded-full bg-white flex items-center justify-center text-[#506260] shrink-0 mt-0.5">
                <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-[17px] font-bold text-[#181b2b]">
                  Tiket QR Anda Berhasil Dibuat!
                </h2>
                <p className="text-[13px] text-[#464651] mt-0.5">
                  Tunjukkan QR Code{' '}
                  <span className="font-mono-code font-bold text-[#181b2b]">
                    {myCreatedPass.couponCode}
                  </span>{' '}
                  di bawah ini kepada petugas saat tiba di loket acara.
                </p>
              </div>
            </div>

            {/* User's Created QR Ticket */}
            <DigitalPassCard pass={myCreatedPass} canvasBg="cream" />

            {/* Action to Register Another Ticket */}
            <div className="text-center pt-2 no-print">
              <button
                type="button"
                onClick={() => setUserStep('form')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-[14px] font-medium text-[#464651] hover:text-[#181b2b] hover:bg-black/5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Halaman Sambutan &amp; Formulir</span>
              </button>
            </div>
          </div>
        ) : (
          <RegistrationView
            attendees={attendees}
            nextCouponCode={getNextCouponCode()}
            onRegister={handleRegister}
          />
        )}
      </main>
    </div>
  );
}
