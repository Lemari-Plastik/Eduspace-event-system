import React, { useEffect, useRef, useState } from 'react';
import {
  AttendeePass,
  EDUPASS_LOGO_URL,
  PassStatus,
  ScanFeedback,
  ScanLogEntry,
  TrialClassType
} from '../types';

export type AdminPageId = 'admin-scanner' | 'activity-history' | 'admin-participants';

interface AdminScannerDeskProps {
  attendees: AttendeePass[];
  scanLogs: ScanLogEntry[];
  activePage: AdminPageId;
  onChangePage: (page: AdminPageId) => void;
  onProcessScanCode: (code: string, method: 'auto' | 'manual') => ScanFeedback;
  onQuickRedeem: (passId: string) => void;
  onDeleteAttendee: (passId: string) => void;
  onLogout: () => void;
}

export const AdminScannerDesk: React.FC<AdminScannerDeskProps> = ({
  attendees,
  scanLogs,
  activePage,
  onChangePage,
  onProcessScanCode,
  onQuickRedeem,
  onDeleteAttendee,
  onLogout,
}) => {
  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const t = setTimeout(() => setToastMessage(null), 3200);
    return () => clearTimeout(t);
  }, [toastMessage]);

  // Scanner page states
  const [couponInput, setCouponInput] = useState('ABSC-0002');
  const [flashOn, setFlashOn] = useState(false);
  const [camFlipped, setCamFlipped] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Participants page states
  const [participantSearch, setParticipantSearch] = useState('');
  const [participantStatusFilter, setParticipantStatusFilter] = useState<
    'ALL' | PassStatus
  >('ALL');
  const [participantClassFilter, setParticipantClassFilter] = useState<
    'ALL' | TrialClassType
  >('ALL');
  const [pendingDeletePass, setPendingDeletePass] = useState<AttendeePass | null>(
    null
  );
  const [participantPage, setParticipantPage] = useState(1);

  // Activity Log page states
  const [logSearch, setLogSearch] = useState('');
  const [logStatusFilter, setLogStatusFilter] = useState<
    'all' | 'success' | 'rejected' | 'manual'
  >('all');
  const [isExportingLog, setIsExportingLog] = useState(false);

  // Cleanup camera stream
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((tr) => tr.stop());
      }
    };
  }, []);

  const toggleLiveCamera = async () => {
    if (cameraActive) {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((tr) => tr.stop());
        streamRef.current = null;
      }
      setCameraActive(false);
      return;
    }

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: camFlipped ? 'user' : 'environment' },
          audio: false,
        });
        streamRef.current = stream;
        setCameraActive(true);
        setTimeout(() => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        }, 50);
      } else {
        showToast('Kamera perangkat tidak tersedia di peramban ini.');
      }
    } catch {
      showToast('Izin kamera belum diberikan. Gunakan input manual kupon.');
    }
  };

  // KPI calculations
  const totalCount = attendees.length;
  const redeemedCount = attendees.filter((a) => a.status === 'REDEEMED').length;
  const unredeemedCount = attendees.filter((a) => a.status === 'UNREDEEMED').length;
  const rejectedLogsCount = scanLogs.filter((l) => l.status === 'rejected').length;
  const hadPercentage =
    totalCount > 0 ? ((redeemedCount / totalCount) * 100).toFixed(1) : '0.0';

  // Filtered participants
  const filteredParticipants = attendees.filter((p) => {
    const matchesStatus =
      participantStatusFilter === 'ALL' || p.status === participantStatusFilter;
    const matchesClass =
      participantClassFilter === 'ALL' || p.trialClass === participantClassFilter;
    const q = participantSearch.trim().toLowerCase();
    const matchesSearch =
      !q ||
      p.fullName.toLowerCase().includes(q) ||
      p.couponCode.toLowerCase().includes(q) ||
      p.nisnOrNip.toLowerCase().includes(q) ||
      p.schoolOrigin.toLowerCase().includes(q) ||
      p.infoSource.toLowerCase().includes(q) ||
      (p.infoSourceDetail && p.infoSourceDetail.toLowerCase().includes(q));
    return matchesStatus && matchesClass && matchesSearch;
  });

  // Filtered activity logs
  const filteredLogs = scanLogs.filter((log) => {
    const matchesTab =
      logStatusFilter === 'all' || log.status === logStatusFilter;
    const q = logSearch.trim().toLowerCase();
    const matchesQuery =
      !q ||
      log.fullName.toLowerCase().includes(q) ||
      log.couponCode.toLowerCase().includes(q) ||
      log.schoolOrigin.toLowerCase().includes(q) ||
      log.deskName.toLowerCase().includes(q) ||
      log.verifierNote.toLowerCase().includes(q);
    return matchesTab && matchesQuery;
  });

  const handleCopyCode = (code: string) => {
    navigator.clipboard?.writeText(code);
    showToast(`Kupon ${code} disalin ke clipboard!`);
  };

  const renderTrialClassBadge = (tc: TrialClassType) => {
    switch (tc) {
      case 'IT':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary-fixed text-on-primary-container text-label-badge font-semibold">
            <span className="material-symbols-outlined text-[14px]">laptop_mac</span>
            IT
          </span>
        );
      case 'DKV':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-surface-container-high text-primary text-label-badge font-semibold">
            <span className="material-symbols-outlined text-[14px]">palette</span>
            DKV
          </span>
        );
      case 'KULINER':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-tertiary-fixed text-on-tertiary-fixed text-label-badge font-semibold">
            <span className="material-symbols-outlined text-[14px]">
              restaurant_menu
            </span>
            KULINER
          </span>
        );
      case 'MOBILE_LEGENDS':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed text-label-badge font-semibold">
            <span className="material-symbols-outlined text-[14px]">
              sports_esports
            </span>
            MOBILE LEGENDS
          </span>
        );
    }
  };

  const handleExportParticipantsCsv = () => {
    const headers = [
      'No',
      'Kode Kupon',
      'Nama Peserta',
      'Peran',
      'NISN / NIP',
      'Asal Sekolah',
      'Trial Class',
      'Sumber Informasi',
      'Detail Sumber',
      'Status Kehadiran',
      'Waktu Hadir',
    ];
    const rows = attendees.map((p, idx) =>
      [
        idx + 1,
        p.couponCode,
        `"${p.fullName.replace(/"/g, '""')}"`,
        p.role,
        p.nisnOrNip,
        `"${p.schoolOrigin.replace(/"/g, '""')}"`,
        p.trialClass,
        p.infoSource,
        `"${(p.infoSourceDetail || '-').replace(/"/g, '""')}"`,
        p.status === 'REDEEMED' ? 'Sudah Hadir' : 'Belum Hadir',
        p.checkedInAt || '-',
      ].join(',')
    );

    const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'data_peserta_openhouse_2026.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('File data_peserta_openhouse_2026.csv berhasil diunduh!');
  };

  const handleExportLogsCsv = () => {
    setIsExportingLog(true);
    setTimeout(() => {
      const headers = [
        'Timestamp',
        'Kode Kupon',
        'Nama Peserta',
        'Asal Sekolah',
        'Peran',
        'Trial Class',
        'Sumber Informasi',
        'Metode Pemindaian',
        'Status & Respons',
      ];
      const rows = scanLogs.map((l) =>
        [
          l.timestamp,
          l.couponCode,
          `"${l.fullName.replace(/"/g, '""')}"`,
          `"${l.schoolOrigin.replace(/"/g, '""')}"`,
          l.role,
          l.trialClass,
          `"${l.infoSource}${l.infoSourceDetail ? ' - ' + l.infoSourceDetail : ''}"`,
          l.scanMethod === 'auto' ? 'Kamera Scanner Auto' : 'Input Manual Loket',
          `"${l.statusText}"`,
        ].join(',')
      );

      const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'riwayat_aktivitas_scan_2026.csv';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setIsExportingLog(false);
      showToast('File riwayat_aktivitas_scan_2026.csv berhasil diunduh!');
    }, 600);
  };

  const handleVerifyFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = couponInput.trim().toUpperCase();
    if (!clean) return;
    const fb = onProcessScanCode(clean, 'manual');
    if (fb.type === 'success') {
      showToast(`Berhasil: Kupon ${clean} valid dan status kehadiran tersimpan!`);
    } else {
      showToast(fb.title + ' — ' + clean);
    }
  };

  return (
    <div className="bg-canvas-admin font-sans text-body-regular text-on-surface min-h-screen">
      {/* Left Fixed Sidebar (Status Scanner Aktif card removed & replaced with simple Logout button per Req #3) */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-surface-container-low z-40 hidden lg:flex flex-col pt-space-lg pb-space-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)]">
        <div className="px-space-md mb-space-lg flex items-center gap-space-xs">
          <img
            alt="OpenHouse Pass Logo"
            referrerPolicy="no-referrer"
            className="h-7 w-auto object-contain"
            src={EDUPASS_LOGO_URL}
          />
          <div className="flex flex-col">
            <span className="font-display text-headline-md text-primary leading-tight">
              EduPass Admin
            </span>
            <span className="text-label-badge text-text-muted">
              Desk &amp; Scan Console
            </span>
          </div>
        </div>

        <nav className="flex-1 px-space-sm flex flex-col gap-space-xs">
          <button
            type="button"
            onClick={() => onChangePage('admin-scanner')}
            className={`w-full flex items-center px-space-md py-space-sm rounded-lg transition-all cursor-pointer text-left ${
              activePage === 'admin-scanner'
                ? 'bg-primary-container text-on-primary-container font-medium'
                : 'text-on-surface-variant font-medium hover:bg-surface-container-high hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined mr-space-sm text-[20px]">
              qr_code_scanner
            </span>
            Barcode Scanner
          </button>

          <button
            type="button"
            onClick={() => onChangePage('activity-history')}
            className={`w-full flex items-center px-space-md py-space-sm rounded-lg transition-all cursor-pointer text-left ${
              activePage === 'activity-history'
                ? 'bg-primary-container text-on-primary-container font-medium'
                : 'text-on-surface-variant font-medium hover:bg-surface-container-high hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined mr-space-sm text-[20px]">
              history
            </span>
            Riwayat Aktivitas
          </button>

          <button
            type="button"
            onClick={() => onChangePage('admin-participants')}
            className={`w-full flex items-center px-space-md py-space-sm rounded-lg transition-all cursor-pointer text-left ${
              activePage === 'admin-participants'
                ? 'bg-primary-container text-on-primary-container font-medium'
                : 'text-on-surface-variant font-medium hover:bg-surface-container-high hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined mr-space-sm text-[20px]">
              group
            </span>
            Daftar Peserta
          </button>
        </nav>

        {/* Simple Logout Button (Req #3) */}
        <div className="px-space-sm">
          <button
            type="button"
            onClick={onLogout}
            className="w-full flex items-center px-space-md py-space-sm rounded-lg text-coral-dark hover:bg-error-container/50 font-medium text-body-medium transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined mr-space-sm text-[20px]">
              logout
            </span>
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Wrapper with Left Sidebar Offset on lg+ */}
      <div className="lg:pl-64">
        {/* Top Fixed Header (Removed "Sesi 1: 08:00 - 12:00 WIB" per Req #6 & Removed "Mode User Biasa" button per Req #4) */}
        <header className="fixed top-0 left-0 lg:left-64 right-0 h-16 bg-surface/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)] z-30 flex items-center justify-between px-space-lg">
          <div className="flex items-center gap-space-md">
            <span className="font-display text-headline-md text-on-surface">
              Admissions Desk Control
            </span>

            {/* Mobile/Tablet Page Switcher Pills */}
            <div className="flex lg:hidden items-center gap-1 bg-surface-container p-1 rounded-xl">
              <button
                type="button"
                onClick={() => onChangePage('admin-scanner')}
                className={`px-2.5 py-1 rounded-lg text-[12px] font-medium cursor-pointer ${
                  activePage === 'admin-scanner'
                    ? 'bg-primary-container text-on-primary-container'
                    : 'text-text-muted'
                }`}
              >
                Scanner
              </button>
              <button
                type="button"
                onClick={() => onChangePage('activity-history')}
                className={`px-2.5 py-1 rounded-lg text-[12px] font-medium cursor-pointer ${
                  activePage === 'activity-history'
                    ? 'bg-primary-container text-on-primary-container'
                    : 'text-text-muted'
                }`}
              >
                Riwayat
              </button>
              <button
                type="button"
                onClick={() => onChangePage('admin-participants')}
                className={`px-2.5 py-1 rounded-lg text-[12px] font-medium cursor-pointer ${
                  activePage === 'admin-participants'
                    ? 'bg-primary-container text-on-primary-container'
                    : 'text-text-muted'
                }`}
              >
                Peserta
              </button>
              <button
                type="button"
                onClick={onLogout}
                className="px-2.5 py-1 rounded-lg text-[12px] font-medium text-coral-dark cursor-pointer"
              >
                Logout
              </button>
            </div>
          </div>

          <div className="flex items-center gap-space-md">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-on-primary text-[18px]">
                person
              </span>
            </div>
          </div>
        </header>

        {/* Main Workspace Container */}
        <main className="relative pt-22 bg-canvas-admin min-h-screen px-space-lg pb-space-xl">
          {/* Toast Notification */}
          <div
            className={`fixed bottom-6 right-6 z-50 transform transition-all duration-300 pointer-events-none flex items-center gap-space-sm bg-inverse-surface text-inverse-on-surface px-space-md py-space-sm rounded-xl shadow-xl ${
              toastMessage
                ? 'translate-y-0 opacity-100'
                : 'translate-y-24 opacity-0'
            }`}
          >
            <span className="material-symbols-outlined text-[20px] text-primary-container">
              check_circle
            </span>
            <span className="font-medium text-body-medium">{toastMessage}</span>
          </div>

          {/* Delete Confirmation Modal */}
          {pendingDeletePass && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-on-surface/40 backdrop-blur-sm p-4">
              <div className="bg-surface rounded-2xl max-w-md w-full p-space-lg shadow-2xl flex flex-col gap-space-md">
                <div className="w-12 h-12 rounded-full bg-error-container text-error flex items-center justify-center">
                  <span className="material-symbols-outlined text-[26px]">
                    warning
                  </span>
                </div>
                <div>
                  <h3 className="font-display text-headline-md text-on-surface mb-1">
                    Hapus Data Peserta?
                  </h3>
                  <p className="text-body-regular text-text-muted">
                    Anda yakin ingin menghapus data &ldquo;
                    {pendingDeletePass.fullName} ({pendingDeletePass.couponCode})
                    &rdquo;? Peserta yang dihapus tidak akan dapat menggunakan kupon mereka lagi untuk verifikasi kehadiran.
                  </p>
                </div>
                <div className="flex items-center justify-end gap-space-sm pt-2">
                  <button
                    type="button"
                    onClick={() => setPendingDeletePass(null)}
                    className="h-12 px-space-md rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface font-medium text-body-medium transition-all cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteAttendee(pendingDeletePass.id);
                      setPendingDeletePass(null);
                      showToast('Data peserta berhasil dihapus dari sistem.');
                    }}
                    className="h-12 px-space-md rounded-xl bg-coral-alert hover:bg-coral-dark text-on-primary font-medium text-body-medium shadow-sm transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px]">
                      delete_forever
                    </span>
                    Ya, Hapus
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* PAGE 1: BARCODE SCANNER (Admin Fast Coupon Scanner)                 */}
          {/* =================================================================== */}
          {activePage === 'admin-scanner' && (
            <div className="flex flex-col w-full">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-space-md mb-space-lg">
                <div>
                  <h1 className="font-display text-headline-lg text-on-surface tracking-tight">
                    Verifikasi &amp; Scan Kehadiran
                  </h1>
                </div>
              </div>

              {/* Operational Metrics Strip */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-space-md mb-space-lg">
                <div className="bg-surface rounded-xl p-space-md shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-body-sm text-text-muted">Total Registrasi</p>
                    <p className="font-display text-headline-lg text-on-surface mt-0.5">
                      {totalCount}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-surface-container flex items-center justify-center text-primary">
                    <span className="material-symbols-outlined text-[22px]">
                      badge
                    </span>
                  </div>
                </div>

                <div className="bg-surface rounded-xl p-space-md shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-body-sm text-text-muted">Tervalidasi Hadir</p>
                    <p className="font-display text-headline-lg text-on-surface mt-0.5">
                      {redeemedCount}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-secondary-container flex items-center justify-center text-on-secondary-fixed">
                    <span className="material-symbols-outlined text-[22px]">
                      verified
                    </span>
                  </div>
                </div>

                <div className="bg-surface rounded-xl p-space-md shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-body-sm text-text-muted">Belum Hadir</p>
                    <p className="font-display text-headline-lg text-on-surface mt-0.5">
                      {unredeemedCount}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-neutral-badge-bg flex items-center justify-center text-text-muted">
                    <span className="material-symbols-outlined text-[22px]">
                      schedule
                    </span>
                  </div>
                </div>

                <div className="bg-surface rounded-xl p-space-md shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-body-sm text-text-muted">Duplikat Tercegah</p>
                    <p className="font-display text-headline-lg text-coral-dark mt-0.5">
                      {rejectedLogsCount}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-error-container flex items-center justify-center text-coral-dark">
                    <span className="material-symbols-outlined text-[22px]">
                      flip_camera_ios
                    </span>
                  </div>
                </div>
              </div>

              {/* Main Workspace Grid: Viewfinder & Manual Input */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-lg w-full">
                {/* Camera Viewfinder Card */}
                <div className="lg:col-span-12 flex flex-col gap-space-md">
                  <div className="bg-surface rounded-2xl p-space-lg shadow-sm flex flex-col">
                    <div className="flex items-center justify-between mb-space-md">
                      <div className="flex items-center gap-space-xs">
                        <span className="flex h-3 w-3 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-container opacity-75" />
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-primary" />
                        </span>
                        <span className="font-display text-headline-md text-on-surface">
                          Kamera Pemindai Aktif
                        </span>
                      </div>

                      <div className="flex items-center gap-space-xs">
                        <button
                          type="button"
                          onClick={toggleLiveCamera}
                          className={`h-10 px-3 rounded-xl text-body-sm font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
                            cameraActive
                              ? 'bg-primary-container text-on-primary-container'
                              : 'bg-surface-container hover:bg-surface-container-high text-on-surface'
                          }`}
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            {cameraActive ? 'videocam_off' : 'videocam'}
                          </span>
                          <span>{cameraActive ? 'Matikan Kamera' : 'Buka Kamera'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setFlashOn((v) => !v)}
                          title="Flashlight"
                          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                            flashOn
                              ? 'bg-primary-container text-on-primary-container'
                              : 'bg-surface-container hover:bg-surface-container-high text-on-surface'
                          }`}
                        >
                          <span className="material-symbols-outlined text-[20px]">
                            flashlight_on
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setCamFlipped((v) => !v)}
                          title="Ganti Kamera Depan/Belakang"
                          className={`w-10 h-10 rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface flex items-center justify-center transition-all cursor-pointer ${
                            camFlipped ? 'rotate-180' : ''
                          }`}
                        >
                          <span className="material-symbols-outlined text-[20px]">
                            flip_camera_ios
                          </span>
                        </button>
                      </div>
                    </div>

                    <div className="relative w-full aspect-video sm:h-[420px] rounded-2xl overflow-hidden bg-on-surface flex items-center justify-center shadow-inner">
                      {cameraActive ? (
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="absolute inset-0 w-full h-full object-cover opacity-90"
                        />
                      ) : (
                        <div className="absolute inset-0 bg-gradient-to-b from-inverse-surface/90 via-on-surface to-inverse-surface flex items-center justify-center">
                          <div className="w-full h-full opacity-10 bg-[radial-gradient(#9FA0FF_1px,transparent_1px)] [background-size:16px_16px]" />
                        </div>
                      )}

                      <div className="relative z-10 w-72 h-52 sm:w-96 sm:h-64 flex items-center justify-center">
                        <div className="absolute top-0 left-0 w-10 h-10 rounded-tl-xl border-t-4 border-l-4 border-primary-container" />
                        <div className="absolute top-0 right-0 w-10 h-10 rounded-tr-xl border-t-4 border-r-4 border-primary-container" />
                        <div className="absolute bottom-0 left-0 w-10 h-10 rounded-bl-xl border-b-4 border-l-4 border-primary-container" />
                        <div className="absolute bottom-0 right-0 w-10 h-10 rounded-br-xl border-b-4 border-r-4 border-primary-container" />
                        <div className="absolute inset-x-2 h-1 bg-gradient-to-r from-transparent via-primary-container to-transparent shadow-[0_0_16px_#9FA0FF] animate-pulse" />
                        <div className="w-16 h-16 rounded-full bg-primary-container/10 flex items-center justify-center">
                          <span className="material-symbols-outlined text-primary-container/70 text-[32px]">
                            filter_center_focus
                          </span>
                        </div>
                      </div>

                      <div className="absolute bottom-4 inset-x-4 z-20 flex justify-center">
                        <span className="px-space-md py-1.5 rounded-full bg-inverse-surface/85 backdrop-blur-md text-inverse-on-surface text-body-sm flex items-center gap-1.5">
                          <span className="material-symbols-outlined text-primary-container text-[16px]">
                            qr_code_scanner
                          </span>
                          <span>
                            Arahkan QR kupon peserta ke dalam kotak pemindai
                          </span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Manual Input Card (Removed "Preset Pilihan Cepat" per Req #2) */}
                <div className="lg:col-span-12 flex flex-col gap-space-md">
                  <div className="bg-surface rounded-2xl p-space-lg shadow-sm">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-xs mb-space-md">
                      <div className="flex items-center gap-space-xs">
                        <span className="material-symbols-outlined text-primary text-[22px]">
                          keyboard
                        </span>
                        <span className="font-display text-headline-md text-on-surface">
                          Input Manual Kupon
                        </span>
                      </div>
                      <span className="text-body-sm text-text-muted">
                        Gunakan opsi ini jika QR rusak atau tidak terbaca
                      </span>
                    </div>

                    <form
                      onSubmit={handleVerifyFormSubmit}
                      className="flex flex-col md:flex-row gap-space-sm items-stretch"
                    >
                      <div className="relative flex-1">
                        <div className="absolute inset-y-0 left-0 pl-space-md flex items-center pointer-events-none text-text-muted">
                          <span className="material-symbols-outlined text-[22px]">
                            pin
                          </span>
                        </div>
                        <input
                          type="text"
                          maxLength={12}
                          value={couponInput}
                          onChange={(e) =>
                            setCouponInput(e.target.value.toUpperCase())
                          }
                          placeholder="ABSC-0001"
                          className="w-full h-[52px] pl-12 pr-4 rounded-xl bg-surface-container-lowest border border-border-subtle text-on-surface font-mono-code text-code-coupon-md uppercase tracking-wider focus:outline-none focus:bg-surface-container-low transition-all"
                        />
                      </div>

                      <button
                        type="submit"
                        className="h-[52px] px-space-lg rounded-xl bg-primary-container hover:bg-primary-dark text-on-primary-container font-display text-headline-md flex items-center justify-center gap-space-xs shadow-md transition-all active:scale-[0.98] whitespace-nowrap cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[20px]">
                          verified
                        </span>
                        <span>Verifikasi Kupon</span>
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* PAGE 2: RIWAYAT AKTIVITAS (3-Card KPI Row per Req #5)               */}
          {/* =================================================================== */}
          {activePage === 'activity-history' && (
            <div className="flex flex-col w-full">
              {/* Dynamic Top Bar & Metric Overview */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-space-md mb-space-lg">
                <div>
                  <h1 className="font-display text-headline-lg text-on-surface tracking-tight">
                    Riwayat Aktivitas &amp; Log Pemindaian
                  </h1>
                  <p className="text-body-regular text-text-muted mt-0.5">
                    Catatan kronologis menyeluruh pemindaian kupon masuk, verifikasi kehadiran, dan deteksi duplikat tiket secara real-time.
                  </p>
                </div>
                <div className="flex items-center gap-space-sm self-start lg:self-center">
                  <button
                    type="button"
                    onClick={handleExportLogsCsv}
                    className="inline-flex items-center gap-space-xs px-space-md py-2.5 rounded-xl bg-surface-container-lowest text-on-surface font-medium text-body-medium hover:bg-surface-container-high transition-all shadow-sm cursor-pointer"
                  >
                    <span
                      className={`material-symbols-outlined text-[18px] text-primary ${
                        isExportingLog ? 'animate-spin' : ''
                      }`}
                    >
                      {isExportingLog ? 'progress_activity' : 'download'}
                    </span>
                    <span>
                      {isExportingLog ? 'Mengekspor...' : 'Export CSV / Excel'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Key Metrics 3-Card Row (4th KPI card removed per Req #5) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-space-md mb-space-lg">
                {/* Card 1: Total Scans */}
                <div className="relative overflow-hidden rounded-xl bg-surface-container-lowest p-space-md shadow-sm transition-all hover:shadow-md flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-label-badge text-text-muted block">
                        Total Log Scan Hari Ini
                      </span>
                      <span className="font-display text-display-hero text-on-surface mt-1 block">
                        {scanLogs.length}
                      </span>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-primary-container/20 flex items-center justify-center text-primary">
                      <span className="material-symbols-outlined text-[22px]">
                        document_scanner
                      </span>
                    </div>
                  </div>
                  <div className="mt-space-md flex items-center justify-between pt-space-xs">
                    <div className="flex items-center gap-1.5 text-label-badge text-secondary font-semibold">
                      <span className="material-symbols-outlined text-[16px]">
                        sync
                      </span>
                      <span>100% Tersinkronisasi</span>
                    </div>
                  </div>
                  <div className="w-full bg-surface-container h-1 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-primary h-full rounded-full"
                      style={{ width: '78%' }}
                    />
                  </div>
                </div>

                {/* Card 2: Successful Check-ins */}
                <div className="relative overflow-hidden rounded-xl bg-surface-container-lowest p-space-md shadow-sm transition-all hover:shadow-md flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-label-badge text-text-muted block">
                        Scan Berhasil / Hadir
                      </span>
                      <span className="font-display text-display-hero text-on-surface mt-1 block">
                        {
                          scanLogs.filter(
                            (l) => l.status === 'success' || l.status === 'manual'
                          ).length
                        }
                      </span>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-secondary-container flex items-center justify-center text-on-secondary-fixed">
                      <span className="material-symbols-outlined text-[22px]">
                        check_circle
                      </span>
                    </div>
                  </div>
                  <div className="mt-space-md flex items-center justify-between pt-space-xs">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-secondary-container text-on-secondary-fixed text-label-badge font-semibold">
                      <span className="material-symbols-outlined text-[14px]">
                        done_all
                      </span>{' '}
                      {hadPercentage}% Hadir
                    </span>
                  </div>
                  <div className="w-full bg-surface-container h-1 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-secondary h-full rounded-full"
                      style={{ width: `${hadPercentage}%` }}
                    />
                  </div>
                </div>

                {/* Card 3: Duplicates & Rejected */}
                <div className="relative overflow-hidden rounded-xl bg-surface-container-lowest p-space-md shadow-sm transition-all hover:shadow-md flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-label-badge text-text-muted block">
                        Gagal Verifikasi
                      </span>
                      <span className="font-display text-display-hero text-coral-dark mt-1 block">
                        {rejectedLogsCount}
                      </span>
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-error-container flex items-center justify-center text-error">
                      <span className="material-symbols-outlined text-[22px]">
                        gpp_bad
                      </span>
                    </div>
                  </div>
                  <div className="mt-space-md flex items-center justify-between pt-space-xs">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-error-container text-error text-label-badge font-semibold">
                      <span className="material-symbols-outlined text-[14px]">
                        warning
                      </span>{' '}
                      {rejectedLogsCount} Terdeteksi &amp; Ditolak
                    </span>
                  </div>
                  <div className="w-full bg-surface-container h-1 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-coral-alert h-full rounded-full"
                      style={{ width: '18%' }}
                    />
                  </div>
                </div>
              </div>

              {/* Operational Filter Toolbar */}
              <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm mb-space-md">
                <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-space-md">
                  <div className="relative flex-1 min-w-[280px]">
                    <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted text-[20px]">
                      search
                    </span>
                    <input
                      type="text"
                      value={logSearch}
                      onChange={(e) => setLogSearch(e.target.value)}
                      placeholder="Cari nama peserta, kode kupon, atau ID petugas..."
                      className="w-full h-12 pl-10 pr-4 bg-surface-container-lowest text-on-surface text-body-regular rounded-xl outline-none transition-all placeholder:text-text-muted shadow-sm focus:ring-2 focus:ring-primary-container/40 border border-border-subtle"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-space-sm">
                    <div className="inline-flex p-1 bg-surface-container rounded-xl overflow-x-auto">
                      {(
                        [
                          { id: 'all', label: 'Semua Log' },
                          { id: 'success', label: 'Berhasil Validasi (200)' },
                          { id: 'rejected', label: 'Duplikat / Ditolak (422)' },
                          { id: 'manual', label: 'Input Manual' },
                        ] as const
                      ).map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setLogStatusFilter(tab.id)}
                          className={`px-3.5 py-1.5 rounded-lg text-body-sm transition-all cursor-pointer whitespace-nowrap ${
                            logStatusFilter === tab.id
                              ? 'bg-surface-container-lowest text-on-surface shadow-sm font-semibold'
                              : 'text-text-muted hover:text-on-surface font-medium'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Real-Time Activity Timeline / Ledger Table */}
              <div className="bg-surface-container-lowest rounded-xl shadow-sm overflow-hidden flex flex-col">
                <div className="px-space-lg py-space-sm bg-surface-container/50 flex flex-wrap items-center justify-between gap-space-xs text-text-muted text-body-sm">
                  <div className="flex items-center gap-space-sm">
                    <span className="flex items-center gap-1 text-on-surface font-medium text-body-medium">
                      <span className="material-symbols-outlined text-primary text-[18px]">
                        format_list_bulleted
                      </span>
                      <span>Aliran Data Pemindaian Terkini</span>
                    </span>
                  </div>
                </div>

                <div className="overflow-x-auto w-full">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-surface-container-low text-on-surface-variant text-label-badge">
                        <th className="py-3.5 px-space-lg">Timestamp</th>
                        <th className="py-3.5 px-space-md">Kode Kupon</th>
                        <th className="py-3.5 px-space-md">
                          Nama Peserta &amp; Asal Sekolah
                        </th>
                        <th className="py-3.5 px-space-md">
                          Peran &amp; Trial Class
                        </th>
                        <th className="py-3.5 px-space-md">Metode Pemindaian</th>
                        <th className="py-3.5 px-space-lg text-right">
                          Status &amp; Respons
                        </th>
                      </tr>
                    </thead>
                    <tbody className="text-body-regular text-on-surface">
                      {filteredLogs.map((log) => {
                        const isRejected = log.status === 'rejected';
                        return (
                          <tr
                            key={log.id}
                            className={`transition-colors group ${
                              isRejected
                                ? 'bg-error-container/15 hover:bg-error-container/25'
                                : 'hover:bg-surface-container/40'
                            }`}
                          >
                            <td className="py-space-md px-space-lg whitespace-nowrap">
                              <div className="flex flex-col">
                                <span
                                  className={`font-code-sm text-code-sm font-bold ${
                                    isRejected
                                      ? 'text-coral-dark'
                                      : 'text-on-surface'
                                  }`}
                                >
                                  {log.timestamp}
                                </span>
                                <span className="text-body-sm text-text-muted">
                                  {log.relativeTime}
                                </span>
                              </div>
                            </td>

                            <td className="py-space-md px-space-md whitespace-nowrap">
                              <span
                                className={`inline-block px-2.5 py-1 rounded font-code-coupon-md text-[14px] leading-tight font-bold ${
                                  isRejected
                                    ? 'bg-error-container text-coral-dark'
                                    : 'bg-surface-container-high text-primary'
                                }`}
                              >
                                {log.couponCode}
                              </span>
                            </td>

                            <td className="py-space-md px-space-md min-w-[220px]">
                              <div className="flex flex-col">
                                <span
                                  className={`font-medium text-body-medium font-semibold text-on-surface transition-colors ${
                                    isRejected
                                      ? 'group-hover:text-coral-dark'
                                      : 'group-hover:text-primary'
                                  }`}
                                >
                                  {log.fullName}
                                </span>
                                <span className="text-body-sm text-text-muted">
                                  {log.schoolOrigin} • Info: {log.infoSource}
                                </span>
                              </div>
                            </td>

                            <td className="py-space-md px-space-md whitespace-nowrap">
                              <div className="flex flex-col gap-1 items-start">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-label-badge ${
                                    log.role === 'Guru Pendamping'
                                      ? 'bg-secondary-container text-on-secondary-fixed'
                                      : 'bg-primary-fixed text-on-primary-fixed'
                                  }`}
                                >
                                  {log.role}
                                </span>
                                {renderTrialClassBadge(log.trialClass)}
                              </div>
                            </td>

                            <td className="py-space-md px-space-md whitespace-nowrap">
                              {log.scanMethod === 'auto' ? (
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-surface-container text-body-sm text-on-surface">
                                  <span className="material-symbols-outlined text-[16px] text-secondary">
                                    photo_camera
                                  </span>
                                  <span>Kamera Scanner Auto</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-surface-container-high text-body-sm text-on-surface">
                                  <span className="material-symbols-outlined text-[16px] text-primary">
                                    keyboard
                                  </span>
                                  <span>Input Manual Loket</span>
                                </span>
                              )}
                            </td>

                            <td className="py-space-md px-space-lg whitespace-nowrap text-right">
                              {isRejected ? (
                                <div className="inline-flex flex-col items-end">
                                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-error-container text-error text-[11px] font-semibold leading-tight">
                                    <span className="material-symbols-outlined text-[13px]">
                                      cancel
                                    </span>
                                    <span>{log.statusText}</span>
                                  </span>
                                  {log.subStatusText && (
                                    <span className="text-[10px] text-coral-dark leading-tight mt-0.5">
                                      {log.subStatusText}
                                    </span>
                                  )}
                                </div>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-secondary-container text-on-secondary-fixed text-[11px] font-semibold leading-tight">
                                  <span className="material-symbols-outlined text-[13px]">
                                    verified
                                  </span>
                                  <span>{log.statusText}</span>
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Pagination Footer */}
                <div className="p-space-md bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
                  <div className="flex items-center gap-space-sm text-text-muted text-body-sm">
                    <span>
                      Menampilkan{' '}
                      <strong className="text-on-surface font-semibold">
                        1-{filteredLogs.length}
                      </strong>{' '}
                      dari{' '}
                      <strong className="text-on-surface font-semibold">
                        {scanLogs.length}
                      </strong>{' '}
                      total log riwayat pemindaian
                    </span>
                  </div>
                  <div className="flex items-center gap-space-xs">
                    <button
                      type="button"
                      disabled
                      className="w-9 h-9 rounded-lg bg-surface-container-lowest text-text-muted flex items-center justify-center disabled:opacity-40"
                    >
                      <span className="material-symbols-outlined text-[18px]">
                        chevron_left
                      </span>
                    </button>
                    <button
                      type="button"
                      className="w-9 h-9 rounded-lg bg-primary text-on-primary text-body-sm font-bold flex items-center justify-center shadow-sm"
                    >
                      1
                    </button>
                    <button
                      type="button"
                      disabled
                      className="w-9 h-9 rounded-lg bg-surface-container-lowest text-text-muted flex items-center justify-center disabled:opacity-40"
                    >
                      <span className="material-symbols-outlined text-[18px]">
                        chevron_right
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* PAGE 3: DAFTAR PESERTA (3-Card KPI Row without Kupon Walk-In)       */}
          {/* =================================================================== */}
          {activePage === 'admin-participants' && (
            <div className="flex flex-col w-full">
              {/* Quick Info Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-sm pb-space-lg">
                <div>
                  <h1 className="font-display text-headline-lg text-on-surface">
                    Data Peserta &amp; Presensi
                  </h1>
                  <p className="text-body-regular text-text-muted mt-0.5">
                    Kelola kupon pendaftaran, status scan kehadiran loket, dan riwayat trial class.
                  </p>
                </div>
              </div>

              {/* Section 1: KPI Top Summary Cards (3 Cards — Removed Kupon Walk-In per Req #5) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-space-md mb-space-lg">
                {/* Card 1: Total Terdaftar */}
                <div className="bg-surface rounded-2xl p-space-md shadow-sm relative overflow-hidden group hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-space-sm">
                    <span className="font-medium text-body-medium text-text-muted">
                      Total Terdaftar
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-primary-container/30 text-on-primary-container flex items-center justify-center">
                      <span className="material-symbols-outlined text-[22px]">
                        group
                      </span>
                    </div>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-display-hero text-on-surface tracking-tight">
                      {totalCount}
                    </span>
                    <span className="text-label-badge text-text-muted">
                      Peserta
                    </span>
                  </div>
                  <div className="mt-space-sm pt-space-xs flex items-center justify-between text-body-sm text-text-muted">
                    <span>Target Sesi: 250</span>
                    <span className="font-semibold text-primary">Aktif</span>
                  </div>
                  <div className="w-full bg-surface-container h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-primary h-full rounded-full"
                      style={{ width: '92%' }}
                    />
                  </div>
                </div>

                {/* Card 2: Sudah Hadir / Di-scan */}
                <div className="bg-surface rounded-2xl p-space-md shadow-sm relative overflow-hidden group hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-space-sm">
                    <span className="font-medium text-body-medium text-text-muted">
                      Sudah Hadir / Di-scan
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-secondary-container text-on-secondary-fixed flex items-center justify-center">
                      <span className="material-symbols-outlined text-[22px]">
                        check_circle
                      </span>
                    </div>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-display-hero text-on-surface tracking-tight">
                      {redeemedCount}
                    </span>
                    <span className="px-space-xs py-0.5 rounded-full bg-secondary-container text-on-secondary-fixed text-label-badge">
                      {hadPercentage}%
                    </span>
                  </div>
                  <div className="mt-space-sm pt-space-xs flex items-center justify-between text-body-sm text-text-muted">
                    <span>Verifikasi Scanner</span>
                    <span className="text-secondary font-medium">
                      {redeemedCount} Berhasil
                    </span>
                  </div>
                  <div className="w-full bg-surface-container h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-secondary h-full rounded-full"
                      style={{ width: `${hadPercentage}%` }}
                    />
                  </div>
                </div>

                {/* Card 3: Belum Hadir */}
                <div className="bg-surface rounded-2xl p-space-md shadow-sm relative overflow-hidden group hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-space-sm">
                    <span className="font-medium text-body-medium text-text-muted">
                      Belum Hadir
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-neutral-badge-bg text-text-muted flex items-center justify-center">
                      <span className="material-symbols-outlined text-[22px]">
                        pending_actions
                      </span>
                    </div>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-display-hero text-on-surface tracking-tight">
                      {unredeemedCount}
                    </span>
                    <span className="px-space-xs py-0.5 rounded-full bg-neutral-badge-bg text-text-muted text-label-badge">
                      Menunggu
                    </span>
                  </div>
                  <div className="mt-space-sm pt-space-xs flex items-center justify-between text-body-sm text-text-muted">
                    <span>Estimasi Hadir</span>
                    <span className="text-text-muted font-medium">
                      Sesi Siang
                    </span>
                  </div>
                  <div className="w-full bg-surface-container h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-outline-variant h-full rounded-full"
                      style={{
                        width: `${
                          totalCount > 0
                            ? ((unredeemedCount / totalCount) * 100).toFixed(1)
                            : 0
                        }%`,
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Filter & Action Toolbar */}
              <div className="bg-surface rounded-2xl p-space-md shadow-sm mb-space-md flex flex-col xl:flex-row gap-space-md items-stretch xl:items-center justify-between">
                <div className="flex flex-col lg:flex-row gap-space-sm items-stretch lg:items-center flex-1">
                  {/* Search Input */}
                  <div className="relative min-w-[280px] lg:max-w-md w-full">
                    <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted text-[20px] pointer-events-none">
                      search
                    </span>
                    <input
                      type="text"
                      value={participantSearch}
                      onChange={(e) => setParticipantSearch(e.target.value)}
                      placeholder="Cari nama peserta atau kode kupon..."
                      className="w-full h-12 pl-10 pr-10 rounded-xl bg-canvas-admin text-on-surface placeholder:text-text-muted text-body-regular focus:outline-none focus:bg-surface focus:shadow-[0_0_0_2px_#9fa0ff] transition-all"
                    />
                    {participantSearch && (
                      <button
                        type="button"
                        aria-label="Bersihkan pencarian"
                        onClick={() => setParticipantSearch('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-on-surface cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-[18px]">
                          cancel
                        </span>
                      </button>
                    )}
                  </div>

                  {/* Segmented Status Filter */}
                  <div className="inline-flex p-1 rounded-xl bg-canvas-admin self-start lg:self-auto overflow-x-auto max-w-full">
                    <button
                      type="button"
                      onClick={() => setParticipantStatusFilter('ALL')}
                      className={`px-space-md h-10 rounded-lg font-medium text-body-sm transition-all whitespace-nowrap cursor-pointer ${
                        participantStatusFilter === 'ALL'
                          ? 'bg-primary-container text-on-primary-container shadow-sm'
                          : 'text-text-muted hover:text-on-surface'
                      }`}
                    >
                      Semua Peserta ({totalCount})
                    </button>
                    <button
                      type="button"
                      onClick={() => setParticipantStatusFilter('UNREDEEMED')}
                      className={`px-space-md h-10 rounded-lg font-medium text-body-sm transition-all whitespace-nowrap cursor-pointer ${
                        participantStatusFilter === 'UNREDEEMED'
                          ? 'bg-primary-container text-on-primary-container shadow-sm'
                          : 'text-text-muted hover:text-on-surface'
                      }`}
                    >
                      Belum Di-scan ({unredeemedCount})
                    </button>
                    <button
                      type="button"
                      onClick={() => setParticipantStatusFilter('REDEEMED')}
                      className={`px-space-md h-10 rounded-lg font-medium text-body-sm transition-all whitespace-nowrap cursor-pointer ${
                        participantStatusFilter === 'REDEEMED'
                          ? 'bg-primary-container text-on-primary-container shadow-sm'
                          : 'text-text-muted hover:text-on-surface'
                      }`}
                    >
                      Sudah Hadir ({redeemedCount})
                    </button>
                  </div>
                </div>

                {/* Right Part: Trial Class Dropdown & Export Action */}
                <div className="flex items-center gap-space-sm flex-wrap xl:flex-nowrap shrink-0">
                  <div className="relative min-w-[190px]">
                    <select
                      value={participantClassFilter}
                      onChange={(e) =>
                        setParticipantClassFilter(
                          e.target.value as 'ALL' | TrialClassType
                        )
                      }
                      className="w-full h-10 pl-space-md pr-10 rounded-xl bg-canvas-admin text-on-surface font-medium text-body-sm appearance-none focus:outline-none focus:shadow-[0_0_0_2px_#9fa0ff] cursor-pointer"
                    >
                      <option value="ALL">Semua Trial Class</option>
                      <option value="IT">IT (Web &amp; App)</option>
                      <option value="DKV">DKV (Desain Grafis)</option>
                      <option value="KULINER">KULINER (Tata Boga)</option>
                      <option value="MOBILE_LEGENDS">MOBILE LEGENDS</option>
                    </select>
                    <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none text-[20px]">
                      expand_more
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={handleExportParticipantsCsv}
                    className="h-10 px-space-md rounded-xl bg-canvas-admin hover:bg-surface-container text-on-surface font-medium text-body-sm transition-all flex items-center gap-space-xs whitespace-nowrap shadow-sm cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px] text-primary">
                      sim_card_download
                    </span>
                    <span>Export CSV/Excel</span>
                  </button>
                </div>
              </div>

              {/* Section 3: High-Fidelity Responsive Data Table */}
              <div className="bg-surface rounded-2xl shadow-sm overflow-hidden flex flex-col">
                <div className="overflow-x-auto w-full">
                  <table className="w-full text-left align-middle border-collapse">
                    <thead>
                      <tr className="bg-tertiary-fixed/30 text-on-surface font-display text-body-sm uppercase tracking-wider select-none">
                        <th className="py-space-md px-space-md w-14 text-center">
                          No
                        </th>
                        <th className="py-space-md px-space-md min-w-[150px]">
                          Kode Kupon
                        </th>
                        <th className="py-space-md px-space-md min-w-[220px]">
                          Nama Peserta &amp; Peran
                        </th>
                        <th className="py-space-md px-space-md min-w-[140px]">
                          NISN / NIP
                        </th>
                        <th className="py-space-md px-space-md min-w-[190px]">
                          Asal Sekolah &amp; Info
                        </th>
                        <th className="py-space-md px-space-md min-w-[160px]">
                          Trial Class
                        </th>
                        <th className="py-space-md px-space-md min-w-[200px]">
                          Status Kehadiran
                        </th>
                        <th className="py-space-md px-space-md w-28 text-center">
                          Aksi
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {filteredParticipants.map((p, index) => (
                        <tr
                          key={p.id}
                          className="hover:bg-primary-container/10 transition-colors duration-150"
                        >
                          <td className="py-space-md px-space-md text-center font-code-sm text-text-muted">
                            {String(index + 1).padStart(2, '0')}
                          </td>

                          <td className="py-space-md px-space-md">
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-surface-container-low font-code-sm text-code-sm text-on-surface">
                              <span className="tracking-wide">{p.couponCode}</span>
                              <button
                                type="button"
                                onClick={() => handleCopyCode(p.couponCode)}
                                title="Salin kode kupon"
                                className="hover:text-primary transition-colors cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-[15px]">
                                  content_copy
                                </span>
                              </button>
                            </div>
                          </td>

                          <td className="py-space-md px-space-md">
                            <div className="flex flex-col">
                              <span className="font-display text-body-medium font-semibold text-on-surface">
                                {p.fullName}
                              </span>
                              <div className="flex items-center gap-1 mt-0.5">
                                {p.role === 'Guru Pendamping' ? (
                                  <span className="px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-body-sm font-medium">
                                    Guru Pendamping
                                  </span>
                                ) : (
                                  <>
                                    <span className="px-2 py-0.5 rounded-full bg-surface-container text-body-sm text-text-muted font-medium">
                                      Siswa
                                    </span>
                                    <span className="text-body-sm text-text-muted">
                                      • {p.registrationSource}
                                    </span>
                                  </>
                                )}
                              </div>
                            </div>
                          </td>

                          <td className="py-space-md px-space-md">
                            <span className="font-code-sm text-code-sm text-on-surface">
                              {p.nisnOrNip}
                            </span>
                          </td>

                          <td className="py-space-md px-space-md">
                            <div className="flex flex-col">
                              <span className="text-body-regular text-on-surface">
                                {p.schoolOrigin}
                              </span>
                              <span className="text-body-sm text-text-muted">
                                Sumber: {p.infoSource}
                                {p.infoSourceDetail
                                  ? ` (${p.infoSourceDetail})`
                                  : ''}
                              </span>
                            </div>
                          </td>

                          <td className="py-space-md px-space-md">
                            {renderTrialClassBadge(p.trialClass)}
                          </td>

                          <td className="py-space-md px-space-md">
                            {p.status === 'REDEEMED' ? (
                              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-secondary-container text-on-secondary-fixed text-label-badge">
                                <span className="material-symbols-outlined text-[16px] text-secondary">
                                  check_circle
                                </span>
                                <span>Hadir - {p.checkedInAt || '09:00 WIB'}</span>
                              </div>
                            ) : (
                              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-badge-bg text-text-muted text-label-badge">
                                <span className="w-2 h-2 rounded-full bg-outline-variant" />
                                <span>Belum Hadir</span>
                              </div>
                            )}
                          </td>

                          <td className="py-space-md px-space-md text-center">
                            <div className="flex items-center justify-center gap-1">
                              {p.status === 'REDEEMED' ? (
                                <button
                                  type="button"
                                  disabled
                                  title="Sudah divalidasi"
                                  className="w-9 h-9 rounded-lg bg-surface-container text-text-muted/40 cursor-not-allowed flex items-center justify-center"
                                >
                                  <span className="material-symbols-outlined text-[18px]">
                                    verified
                                  </span>
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    onQuickRedeem(p.id);
                                    showToast(
                                      `Presensi berhasil diverifikasi untuk ${p.fullName}!`
                                    );
                                  }}
                                  title="Quick Redeem / Presensikan Sekarang"
                                  className="w-9 h-9 rounded-lg bg-primary-container hover:bg-primary-dark text-on-primary-container hover:text-on-primary flex items-center justify-center transition-all shadow-sm cursor-pointer"
                                >
                                  <span className="material-symbols-outlined text-[18px]">
                                    done
                                  </span>
                                </button>
                              )}

                              <button
                                type="button"
                                onClick={() => setPendingDeletePass(p)}
                                title="Hapus data"
                                className="w-9 h-9 rounded-lg hover:bg-coral-alert/15 text-coral-alert hover:text-coral-dark flex items-center justify-center transition-all cursor-pointer"
                              >
                                <span className="material-symbols-outlined text-[18px]">
                                  delete
                                </span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Empty State Display */}
                {filteredParticipants.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
                    <div className="w-16 h-16 rounded-full bg-surface-container flex items-center justify-center text-text-muted mb-space-sm">
                      <span className="material-symbols-outlined text-[32px]">
                        search_off
                      </span>
                    </div>
                    <h4 className="font-display text-headline-md text-on-surface">
                      Data Peserta Tidak Ditemukan
                    </h4>
                    <p className="text-body-regular text-text-muted max-w-sm mt-1">
                      Coba sesuaikan kata kunci pencarian, filter kehadiran, atau opsi trial class.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setParticipantSearch('');
                        setParticipantStatusFilter('ALL');
                        setParticipantClassFilter('ALL');
                      }}
                      className="mt-space-md px-space-md h-10 rounded-xl bg-primary-container text-on-primary-container font-medium text-body-medium cursor-pointer"
                    >
                      Reset Semua Filter
                    </button>
                  </div>
                )}

                {/* Section 4: Pagination Controls */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-space-md p-space-md bg-surface">
                  <span className="text-body-regular text-text-muted order-2 sm:order-1">
                    Menampilkan{' '}
                    <strong className="text-on-surface font-semibold">
                      1-{filteredParticipants.length}
                    </strong>{' '}
                    dari{' '}
                    <strong className="text-on-surface font-semibold">
                      {totalCount}
                    </strong>{' '}
                    peserta
                  </span>

                  <div className="flex items-center gap-1 order-1 sm:order-2">
                    <button
                      type="button"
                      onClick={() =>
                        setParticipantPage((p) => Math.max(1, p - 1))
                      }
                      className="h-10 px-3 rounded-xl bg-canvas-admin hover:bg-surface-container text-text-muted hover:text-on-surface font-medium text-body-sm transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[18px]">
                        chevron_left
                      </span>
                      <span className="hidden md:inline">Sebelumnya</span>
                    </button>

                    <button
                      type="button"
                      className="w-10 h-10 rounded-xl bg-primary-container text-on-primary-container font-medium text-body-sm shadow-sm transition-all"
                    >
                      {participantPage}
                    </button>

                    <button
                      type="button"
                      onClick={() => setParticipantPage((p) => p + 1)}
                      className="h-10 px-3 rounded-xl bg-canvas-admin hover:bg-surface-container text-text-muted hover:text-on-surface font-medium text-body-sm transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <span className="hidden md:inline">Berikutnya</span>
                      <span className="material-symbols-outlined text-[18px]">
                        chevron_right
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
